# CodeSafari 🦁

JavaScript learning adventure for African kids.

## Run locally

    bun install   # or: npm install
    bun dev       # or: npm run dev

Open http://localhost:5173

See CodeSafari-Syllabus.docx for the full curriculum and step-by-step source code walkthrough.
